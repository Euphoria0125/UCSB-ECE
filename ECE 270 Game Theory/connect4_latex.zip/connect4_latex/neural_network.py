"""
Neural Network for AlphaZero Connect 4
Implements a ResNet-style CNN using pure NumPy (no external ML framework required).
Architecture:
  - Input: (3, 6, 7) board state
  - Residual convolutional blocks
  - Policy head: softmax over 7 actions
  - Value head: tanh scalar in [-1, 1]
"""

import numpy as np
import pickle
import os
from typing import Tuple, List


def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)


def softmax(x: np.ndarray) -> np.ndarray:
    x = x - np.max(x)
    e = np.exp(x)
    return e / (e.sum() + 1e-8)


def tanh(x: np.ndarray) -> np.ndarray:
    return np.tanh(x)


def he_init(shape: tuple, fan_in: int) -> np.ndarray:
    """He initialization for ReLU networks."""
    return np.random.randn(*shape) * np.sqrt(2.0 / fan_in)


class Conv2D:
    """2D Convolution layer."""
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3, padding: int = 1):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.padding = padding
        fan_in = in_channels * kernel_size * kernel_size
        self.W = he_init((out_channels, in_channels, kernel_size, kernel_size), fan_in)
        self.b = np.zeros(out_channels)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """x: (C_in, H, W) -> (C_out, H_out, W_out)"""
        C, H, W = x.shape
        if self.padding > 0:
            x_padded = np.pad(x, ((0, 0), (self.padding, self.padding), (self.padding, self.padding)))
        else:
            x_padded = x
        H_out = H
        W_out = W
        out = np.zeros((self.out_channels, H_out, W_out))
        for oc in range(self.out_channels):
            for ic in range(self.in_channels):
                for i in range(H_out):
                    for j in range(W_out):
                        patch = x_padded[ic, i:i+self.kernel_size, j:j+self.kernel_size]
                        out[oc, i, j] += np.sum(patch * self.W[oc, ic])
            out[oc] += self.b[oc]
        return out

    def fast_forward(self, x: np.ndarray) -> np.ndarray:
        """Faster convolution using im2col trick."""
        C, H, W = x.shape
        k = self.kernel_size
        p = self.padding
        if p > 0:
            x_padded = np.pad(x, ((0, 0), (p, p), (p, p)))
        else:
            x_padded = x
        H_out, W_out = H, W

        # Build im2col matrix
        cols = []
        for i in range(H_out):
            for j in range(W_out):
                patch = x_padded[:, i:i+k, j:j+k].flatten()
                cols.append(patch)
        col_matrix = np.array(cols)  # (H*W, C*k*k)

        W_flat = self.W.reshape(self.out_channels, -1)  # (C_out, C*k*k)
        out_flat = col_matrix @ W_flat.T + self.b  # (H*W, C_out)
        return out_flat.T.reshape(self.out_channels, H_out, W_out)

    def __call__(self, x):
        return self.fast_forward(x)


class BatchNorm:
    """Batch normalization (inference mode - uses running stats)."""
    def __init__(self, num_features: int):
        self.gamma = np.ones(num_features)
        self.beta = np.zeros(num_features)
        self.running_mean = np.zeros(num_features)
        self.running_var = np.ones(num_features)
        self.eps = 1e-5
        self.momentum = 0.1

    def forward(self, x: np.ndarray, training: bool = False) -> np.ndarray:
        """x: (C, H, W)"""
        C, H, W = x.shape
        if training:
            mean = x.mean(axis=(1, 2))
            var = x.var(axis=(1, 2))
            self.running_mean = (1 - self.momentum) * self.running_mean + self.momentum * mean
            self.running_var = (1 - self.momentum) * self.running_var + self.momentum * var
        else:
            mean = self.running_mean
            var = self.running_var
        x_norm = (x - mean[:, None, None]) / np.sqrt(var[:, None, None] + self.eps)
        return self.gamma[:, None, None] * x_norm + self.beta[:, None, None]

    def __call__(self, x, training=False):
        return self.forward(x, training)


class Linear:
    """Fully connected layer."""
    def __init__(self, in_features: int, out_features: int):
        self.W = he_init((out_features, in_features), in_features)
        self.b = np.zeros(out_features)

    def __call__(self, x: np.ndarray) -> np.ndarray:
        return x @ self.W.T + self.b


class ResidualBlock:
    """Residual block: Conv -> BN -> ReLU -> Conv -> BN -> (+skip) -> ReLU"""
    def __init__(self, channels: int):
        self.conv1 = Conv2D(channels, channels, 3, padding=1)
        self.bn1 = BatchNorm(channels)
        self.conv2 = Conv2D(channels, channels, 3, padding=1)
        self.bn2 = BatchNorm(channels)

    def forward(self, x: np.ndarray, training: bool = False) -> np.ndarray:
        skip = x
        out = self.conv1(x)
        out = self.bn1(out, training)
        out = relu(out)
        out = self.conv2(out)
        out = self.bn2(out, training)
        out = relu(out + skip)
        return out

    def __call__(self, x, training=False):
        return self.forward(x, training)


class AlphaZeroNet:
    """
    AlphaZero-style network for Connect 4.

    Architecture:
    - Initial conv block: 3 channels -> num_filters
    - num_res_blocks residual blocks
    - Policy head: conv -> flatten -> linear -> softmax (7 actions)
    - Value head: conv -> flatten -> linear -> ReLU -> linear -> tanh
    """

    def __init__(self, num_filters: int = 64, num_res_blocks: int = 3):
        self.num_filters = num_filters
        self.num_res_blocks = num_res_blocks

        # Input conv
        self.input_conv = Conv2D(3, num_filters, 3, padding=1)
        self.input_bn = BatchNorm(num_filters)

        # Residual blocks
        self.res_blocks = [ResidualBlock(num_filters) for _ in range(num_res_blocks)]

        # Policy head
        self.policy_conv = Conv2D(num_filters, 2, 1, padding=0)
        self.policy_bn = BatchNorm(2)
        self.policy_fc = Linear(2 * 6 * 7, 7)

        # Value head
        self.value_conv = Conv2D(num_filters, 1, 1, padding=0)
        self.value_bn = BatchNorm(1)
        self.value_fc1 = Linear(1 * 6 * 7, 64)
        self.value_fc2 = Linear(64, 1)

    def forward(self, state: np.ndarray, training: bool = False) -> Tuple[np.ndarray, float]:
        """
        state: (3, 6, 7)
        Returns: (policy_probs of shape (7,), value scalar)
        """
        x = self.input_conv(state)
        x = self.input_bn(x, training)
        x = relu(x)

        for block in self.res_blocks:
            x = block(x, training)

        # Policy head
        p = self.policy_conv(x)
        p = self.policy_bn(p, training)
        p = relu(p)
        p = p.flatten()
        p = self.policy_fc(p)

        # Value head
        v = self.value_conv(x)
        v = self.value_bn(v, training)
        v = relu(v)
        v = v.flatten()
        v = self.value_fc1(v)
        v = relu(v)
        v = self.value_fc2(v)
        v = tanh(v)[0]

        return p, v

    def predict(self, state: np.ndarray, valid_mask: np.ndarray) -> Tuple[np.ndarray, float]:
        """Get masked policy and value for a state."""
        logits, value = self.forward(state)
        # Mask invalid actions
        logits = logits - 1e9 * (~valid_mask)
        policy = softmax(logits)
        return policy, float(value)

    def get_all_params(self) -> List[np.ndarray]:
        """Collect all parameters for training."""
        params = []
        layers = [
            self.input_conv, self.input_bn,
            *[l for block in self.res_blocks for l in [block.conv1, block.bn1, block.conv2, block.bn2]],
            self.policy_conv, self.policy_bn, self.policy_fc,
            self.value_conv, self.value_bn, self.value_fc1, self.value_fc2
        ]
        for layer in layers:
            for attr in ['W', 'b', 'gamma', 'beta', 'running_mean', 'running_var']:
                if hasattr(layer, attr):
                    params.append(getattr(layer, attr))
        return params

    def save(self, path: str):
        """Save model weights to disk."""
        with open(path, 'wb') as f:
            pickle.dump(self, f)
        print(f"Model saved to {path}")

    @staticmethod
    def load(path: str) -> 'AlphaZeroNet':
        """Load model from disk."""
        with open(path, 'rb') as f:
            model = pickle.load(f)
        print(f"Model loaded from {path}")
        return model
