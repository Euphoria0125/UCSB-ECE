"""
Connect 4 Game Environment
Implements the game logic for Connect 4 as a zero-sum, two-player game.
"""

import numpy as np
from typing import List, Optional, Tuple


class Connect4Env:
    """
    Connect 4 game environment.
    Board is represented as a 6x7 grid.
    Player 1 uses +1, Player 2 uses -1, empty cells are 0.
    """
    ROWS = 6
    COLS = 7
    WIN_LENGTH = 4

    def __init__(self):
        self.board = np.zeros((self.ROWS, self.COLS), dtype=np.int8)
        self.current_player = 1  # Player 1 starts
        self.done = False
        self.winner = None
        self.move_count = 0

    def reset(self) -> np.ndarray:
        self.board = np.zeros((self.ROWS, self.COLS), dtype=np.int8)
        self.current_player = 1
        self.done = False
        self.winner = None
        self.move_count = 0
        return self.get_state()

    def get_valid_actions(self) -> List[int]:
        """Return list of valid column indices (columns that are not full)."""
        if self.done:
            return []
        return [col for col in range(self.COLS) if self.board[0, col] == 0]

    def get_action_mask(self) -> np.ndarray:
        """Return boolean mask of valid actions."""
        mask = np.zeros(self.COLS, dtype=bool)
        for col in self.get_valid_actions():
            mask[col] = True
        return mask

    def drop_piece(self, col: int) -> int:
        """Drop a piece in the given column, return the row where it lands."""
        for row in range(self.ROWS - 1, -1, -1):
            if self.board[row, col] == 0:
                return row
        raise ValueError(f"Column {col} is full")

    def step(self, col: int) -> Tuple[np.ndarray, float, bool]:
        """
        Execute action (drop piece in column col).
        Returns: (next_state, reward, done)
        reward: +1 if current player wins, -1 if loses, 0 otherwise
        """
        if self.done:
            raise ValueError("Game is already over")
        if col not in self.get_valid_actions():
            raise ValueError(f"Invalid action: column {col} is full")

        row = self.drop_piece(col)
        self.board[row, col] = self.current_player
        self.move_count += 1

        # Check for win
        if self._check_win(row, col):
            self.done = True
            self.winner = self.current_player
            reward = 1.0
        elif self.move_count == self.ROWS * self.COLS:
            # Draw
            self.done = True
            self.winner = 0
            reward = 0.0
        else:
            reward = 0.0
            self.current_player *= -1  # Switch player

        return self.get_state(), reward, self.done

    def _check_win(self, row: int, col: int) -> bool:
        """Check if the last move at (row, col) results in a win."""
        player = self.board[row, col]
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]

        for dr, dc in directions:
            count = 1
            # Check in positive direction
            r, c = row + dr, col + dc
            while 0 <= r < self.ROWS and 0 <= c < self.COLS and self.board[r, c] == player:
                count += 1
                r += dr
                c += dc
            # Check in negative direction
            r, c = row - dr, col - dc
            while 0 <= r < self.ROWS and 0 <= c < self.COLS and self.board[r, c] == player:
                count += 1
                r -= dr
                c -= dc
            if count >= self.WIN_LENGTH:
                return True
        return False

    def get_state(self) -> np.ndarray:
        """
        Return state representation for neural network.
        Shape: (3, 6, 7) - [current_player_pieces, opponent_pieces, current_player_indicator]
        """
        state = np.zeros((3, self.ROWS, self.COLS), dtype=np.float32)
        state[0] = (self.board == self.current_player).astype(np.float32)
        state[1] = (self.board == -self.current_player).astype(np.float32)
        state[2] = np.full((self.ROWS, self.COLS), (self.current_player + 1) / 2, dtype=np.float32)
        return state

    def get_state_from_perspective(self, player: int) -> np.ndarray:
        """Get state from a specific player's perspective."""
        state = np.zeros((3, self.ROWS, self.COLS), dtype=np.float32)
        state[0] = (self.board == player).astype(np.float32)
        state[1] = (self.board == -player).astype(np.float32)
        state[2] = np.full((self.ROWS, self.COLS), (player + 1) / 2, dtype=np.float32)
        return state

    def clone(self) -> 'Connect4Env':
        """Return a deep copy of the environment."""
        new_env = Connect4Env()
        new_env.board = self.board.copy()
        new_env.current_player = self.current_player
        new_env.done = self.done
        new_env.winner = self.winner
        new_env.move_count = self.move_count
        return new_env

    def render(self) -> str:
        """Return string representation of the board."""
        symbols = {0: '.', 1: 'X', -1: 'O'}
        rows = []
        rows.append(' '.join(str(i) for i in range(self.COLS)))
        for row in range(self.ROWS):
            rows.append(' '.join(symbols[self.board[row, col]] for col in range(self.COLS)))
        return '\n'.join(rows)

    def print_board(self):
        print(self.render())
        print(f"Current player: {'X' if self.current_player == 1 else 'O'}")
        if self.done:
            if self.winner == 0:
                print("Game over: Draw!")
            else:
                print(f"Game over: {'X' if self.winner == 1 else 'O'} wins!")
