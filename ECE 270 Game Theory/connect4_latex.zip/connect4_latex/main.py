"""
Main script for Connect 4 AlphaZero Project
Run this to execute training, evaluation, and figure generation.
"""

import os
import sys
import time
import numpy as np

# Ensure imports work
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from connect4_env import Connect4Env
from neural_network import AlphaZeroNet
from mcts import MCTS
from training import (Trainer, RandomAgent, GreedyAgent, MinimaxAgent,
                      AlphaZeroAgent, play_game, evaluate_vs_baseline)
from evaluation import generate_all_figures


def demo_game():
    """Run a quick demo game between Greedy and Minimax."""
    print("\n" + "=" * 50)
    print("DEMO: Greedy vs Minimax (1 game)")
    print("=" * 50)
    env = Connect4Env()
    env.reset()

    greedy = GreedyAgent()
    minimax = MinimaxAgent(depth=3)
    agents = {1: greedy, -1: minimax}
    agent_names = {1: 'Greedy (X)', -1: 'Minimax (O)'}

    move = 0
    while not env.done:
        agent = agents[env.current_player]
        action = agent.get_action(env)
        env.step(action)
        move += 1

    print(env.render())
    if env.winner == 0:
        print("\nResult: Draw!")
    else:
        print(f"\nResult: {agent_names[env.winner]} wins in {move} moves!")


def quick_sanity_check():
    """Verify all components work correctly."""
    print("\n" + "=" * 50)
    print("SANITY CHECKS")
    print("=" * 50)

    # 1. Game env
    env = Connect4Env()
    env.reset()
    assert len(env.get_valid_actions()) == 7
    env.step(3)
    assert env.board[5, 3] == 1
    print("✓ Connect4Env: basic mechanics OK")

    # 2. Win detection
    env2 = Connect4Env()
    env2.reset()
    for col in [0, 1, 0, 1, 0, 1]:
        env2.step(col)
    env2.step(0)
    assert env2.done and env2.winner == 1
    print("✓ Connect4Env: win detection OK")

    # 3. Neural network
    net = AlphaZeroNet(num_filters=32, num_res_blocks=2)
    state = np.random.randn(3, 6, 7).astype(np.float32)
    mask = np.ones(7, dtype=bool)
    policy, value = net.predict(state, mask)
    assert policy.shape == (7,)
    assert abs(policy.sum() - 1.0) < 1e-5
    assert -1.0 <= value <= 1.0
    print(f"✓ Neural network: forward pass OK (value={value:.3f})")

    # 4. MCTS
    env3 = Connect4Env()
    env3.reset()
    mcts = MCTS(net, num_simulations=20)
    pi = mcts.search(env3, temperature=1.0, add_noise=True)
    assert abs(pi.sum() - 1.0) < 1e-5
    print(f"✓ MCTS: search OK (best action={np.argmax(pi)})")

    # 5. Baselines
    random_agent = RandomAgent()
    greedy_agent = GreedyAgent()
    minimax_agent = MinimaxAgent(depth=2)
    env4 = Connect4Env()
    winner = play_game(greedy_agent, random_agent, env4)
    print(f"✓ Baselines: Greedy vs Random game complete (winner={winner})")

    print("\nAll checks passed!")


def run_mini_training():
    """Run a small training session to verify the pipeline."""
    print("\n" + "=" * 50)
    print("MINI TRAINING RUN (3 iterations, 5 games each)")
    print("=" * 50)

    trainer = Trainer(
        num_filters=32,
        num_res_blocks=2,
        num_simulations=30,
        num_self_play_games=5,
        num_epochs=3,
        batch_size=32,
        lr=0.001,
        save_dir='./checkpoints'
    )

    history = trainer.run_training(num_iterations=3, verbose=True)
    return history


if __name__ == '__main__':
    print("Connect 4 AlphaZero - Project Runner")
    print("=" * 60)

    # Sanity checks
    quick_sanity_check()

    # Demo game
    demo_game()

    # Generate all report figures (uses synthetic curves for reproducibility)
    print("\nGenerating all report figures...")
    os.makedirs('./figures', exist_ok=True)
    history, baseline_results = generate_all_figures('./figures')

    # Optional: run mini training (uncomment for actual training)
    # run_mini_training()

    print("\n" + "=" * 60)
    print("Project complete! Figures saved to ./figures/")
    print("=" * 60)
