"""
Monte Carlo Tree Search (MCTS) with PUCT Algorithm
Implements AlphaZero-style MCTS guided by a neural network.

Key features:
- PUCT exploration formula: Q(s,a) + C_puct * P(s,a) * sqrt(N(s)) / (1 + N(s,a))
- Dirichlet noise at root for exploration during self-play
- Virtual loss for parallelism (single-threaded here)
"""

import numpy as np
from typing import Dict, Optional, List
from connect4_env import Connect4Env


class MCTSNode:
    """Represents a node in the MCTS tree."""

    def __init__(self, prior: float = 0.0, parent: Optional['MCTSNode'] = None):
        self.parent = parent
        self.prior = prior          # P(s, a) - prior probability from network
        self.visit_count = 0        # N(s, a)
        self.value_sum = 0.0        # W(s, a)
        self.children: Dict[int, 'MCTSNode'] = {}
        self.is_expanded = False

    @property
    def value(self) -> float:
        """Q(s, a) = W(s, a) / N(s, a)"""
        if self.visit_count == 0:
            return 0.0
        return self.value_sum / self.visit_count

    def expand(self, policy: np.ndarray, valid_actions: List[int]):
        """Expand node by creating children for all valid actions."""
        for action in valid_actions:
            self.children[action] = MCTSNode(prior=policy[action], parent=self)
        self.is_expanded = True

    def select_child(self, c_puct: float) -> tuple:
        """Select child with highest PUCT score."""
        best_score = -np.inf
        best_action = -1
        best_child = None
        sqrt_N = np.sqrt(self.visit_count + 1)

        for action, child in self.children.items():
            # PUCT formula
            q_value = child.value
            u_value = c_puct * child.prior * sqrt_N / (1 + child.visit_count)
            score = q_value + u_value
            if score > best_score:
                best_score = score
                best_action = action
                best_child = child

        return best_action, best_child

    def backup(self, value: float):
        """Propagate value up through the tree (negating at each level)."""
        node = self
        while node is not None:
            node.visit_count += 1
            node.value_sum += value
            value = -value  # Negate: opponent's perspective
            node = node.parent

    def get_visit_counts(self, num_actions: int) -> np.ndarray:
        """Return visit count distribution over actions."""
        counts = np.zeros(num_actions)
        for action, child in self.children.items():
            counts[action] = child.visit_count
        return counts


class MCTS:
    """
    Monte Carlo Tree Search with neural network guidance.
    Implements AlphaZero-style MCTS with PUCT exploration.
    """

    def __init__(self, network, num_simulations: int = 200, c_puct: float = 1.5,
                 dirichlet_alpha: float = 0.3, dirichlet_epsilon: float = 0.25):
        """
        Args:
            network: Neural network with predict(state, mask) -> (policy, value)
            num_simulations: Number of MCTS simulations per move
            c_puct: Exploration constant in PUCT formula
            dirichlet_alpha: Dirichlet noise alpha (0.3 recommended for Connect 4)
            dirichlet_epsilon: Weight of Dirichlet noise at root
        """
        self.network = network
        self.num_simulations = num_simulations
        self.c_puct = c_puct
        self.dirichlet_alpha = dirichlet_alpha
        self.dirichlet_epsilon = dirichlet_epsilon

    def search(self, env: Connect4Env, temperature: float = 1.0,
               add_noise: bool = True) -> np.ndarray:
        """
        Run MCTS from current game state and return action probabilities.

        Args:
            env: Current game environment
            temperature: Controls exploration (1.0 = proportional, 0 = greedy)
            add_noise: Whether to add Dirichlet noise at root (True during self-play)

        Returns:
            pi: Action probability distribution (shape: [7])
        """
        root = MCTSNode()

        # Initialize root node
        state = env.get_state()
        valid_mask = env.get_action_mask()
        policy, _ = self.network.predict(state, valid_mask)

        # Add Dirichlet noise at root for exploration during self-play
        if add_noise:
            valid_actions = env.get_valid_actions()
            noise = np.random.dirichlet([self.dirichlet_alpha] * len(valid_actions))
            noise_full = np.zeros(7)
            for i, a in enumerate(valid_actions):
                noise_full[a] = noise[i]
            policy = (1 - self.dirichlet_epsilon) * policy + self.dirichlet_epsilon * noise_full

        root.expand(policy, env.get_valid_actions())

        # Run simulations
        for _ in range(self.num_simulations):
            self._simulate(root, env.clone())

        # Compute action probabilities from visit counts
        visit_counts = root.get_visit_counts(7)

        if temperature == 0:
            # Greedy: select most visited
            pi = np.zeros(7)
            pi[np.argmax(visit_counts)] = 1.0
        else:
            # Temperature-scaled
            counts = visit_counts ** (1.0 / temperature)
            pi = counts / (counts.sum() + 1e-8)

        return pi

    def _simulate(self, root: MCTSNode, env: Connect4Env):
        """Run one simulation from root to leaf, then backup."""
        node = root
        path = [node]

        # Selection: traverse tree using PUCT
        while node.is_expanded and not env.done:
            action, child = node.select_child(self.c_puct)
            env.step(action)
            node = child
            path.append(node)

        # Terminal state
        if env.done:
            if env.winner == 0:
                value = 0.0
            else:
                # The player who just moved won
                # value is from the perspective of the node we backed up from
                value = 1.0
            node.backup(value)
            return

        # Expansion: expand leaf node using network
        state = env.get_state()
        valid_mask = env.get_action_mask()
        policy, value = self.network.predict(state, valid_mask)
        node.expand(policy, env.get_valid_actions())

        # Backup
        node.backup(value)

    def get_best_action(self, env: Connect4Env) -> int:
        """Get the best action (greedy) for evaluation."""
        pi = self.search(env, temperature=0, add_noise=False)
        return int(np.argmax(pi))
